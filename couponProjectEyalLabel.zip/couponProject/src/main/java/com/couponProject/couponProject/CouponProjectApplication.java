package com.couponProject.couponProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CouponProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CouponProjectApplication.class, args);
	}

}
