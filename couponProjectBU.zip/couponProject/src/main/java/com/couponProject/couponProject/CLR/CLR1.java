package com.couponProject.couponProject.CLR;

import com.couponProject.couponProject.LoginManager.ClientType;
import com.couponProject.couponProject.LoginManager.LoginManager;
import com.couponProject.couponProject.Thread.DailyDeleteThread;
import com.couponProject.couponProject.beans.Category;
import com.couponProject.couponProject.beans.Company;
import com.couponProject.couponProject.beans.Coupon;
import com.couponProject.couponProject.beans.Customer;
import com.couponProject.couponProject.repositories.CompanyRepo;
import com.couponProject.couponProject.repositories.CouponRepo;
import com.couponProject.couponProject.services.AdminService;
import com.couponProject.couponProject.services.ClientService;
import com.couponProject.couponProject.services.CompanyService;
import com.couponProject.couponProject.services.CustomerService;
import lombok.NoArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.sql.Date;
import java.time.LocalDate;
@Component
@Order(1)
@RequiredArgsConstructor
public class CLR1 implements CommandLineRunner {
    //private final CompanyService cs;
    private final CompanyRepo companyRepo;
   private final LoginManager loginManager;
   private final CouponRepo couponRepo;
    @Override
    public void run(String... args) throws Exception {
        System.out.println("I work");
        DailyDeleteThread deleteThread=new DailyDeleteThread(couponRepo);
        deleteThread.deleteExpired();
        //companyRepo.save(company1);
      // cs.addCoupon(coupon);
       // System.out.println(cs.getCoupon(1));
       // System.out.println(cs.getCompanyCoupons(Category.FOOD,1));
       // System.out.println(cs.getCompanyCoupons(44,1));

        Company newGoogle=Company.builder()
                .email("google@gmail.com")
                .name("Google")
                .password("456789123")
                .build();
        AdminService as=(AdminService) loginManager.login("admin@admin.com","admin",ClientType.ADMINISTRATOR);
       CustomerService cus=(CustomerService) loginManager.login("juju@gmail.com","jazzyjazz",ClientType.CUSTOMER);
       // as.addCompany(newGoogle);
        CompanyService cs= (CompanyService) loginManager.login("google@gmail.com","456789123", ClientType.COMPANY);
        Coupon coupon=Coupon.builder()
                .title("wow")
                .startDate(Date.valueOf(LocalDate.now()))
                .endDate(Date.valueOf(LocalDate.of(2022,4,15)))
                .price(666)
                .image("asdasd")
                .description("adsasd")
                .category(Category.FOOD)
                .amount(6)
                .build();
        Customer customer=Customer.builder()
                .email("juju@gmail.com")
                .password("jazzyjazz")
                .firstName("jupe")
                .lastName("dupe")
                .coupon(cs.getCoupon(3))
                .build();
        Customer customer2=Customer.builder()

                .email("juji@gmail.com")
                .password("jazzyjazz")
                .firstName("jupe")
                .lastName("dupe")
                .coupon(cs.getCoupon(2))
                .build();
       // cus.purchaseCoupon(cs.getCoupon(10));
        Coupon coupon2=Coupon.builder()
                .company(as.getSingleCompany(1))
                .title("light")
                .startDate(Date.valueOf(LocalDate.now()))
                .endDate(Date.valueOf(LocalDate.of(2022,4,15)))
                .price(666)
                .image("asdasd")
                .description("adsasd")
                .category(Category.ELECTRICITY)
                .amount(6)
                .build();
        Coupon coupon3=Coupon.builder()
                .company(as.getSingleCompany(1))
                .title("deleteplz")
                .startDate(Date.valueOf(LocalDate.now()))
                .endDate(Date.valueOf(LocalDate.of(2021,4,15)))
                .price(666)
                .image("asdasd")
                .description("adsasd")
                .category(Category.ELECTRICITY)
                .amount(6)
                .build();
        //as.addCustomer(customer);
      // cus.purchaseCoupon(cs.getCoupon(8));
        //as.deleteCustomer(4);
       // cs.addCoupon(coupon3);
       // cs.addCoupon(coupon);
        //as.deleteCustomer(2);
       // cs.deleteCoupon(9);
        as.addCustomer(customer);
    //    as.addCustomer(customer2);
       // cus.purchaseCoupon(cs.getCoupon(6));
      //  cus.purchaseCoupon(cs.getCoupon(13));
       // cs.deleteCoupon(13);
       // System.out.println(cus.getAllCustomerCoupons());
        //System.out.println(cus.getAllCustomerCouponsByCategory(Category.FOOD));
//cs.deleteCoupon(12);
    //as.deleteCustomer(7);
       // as.addCustomer(customer2);
       // cs.deleteCoupon(11);
       // as.updateCustomer(customer2);

       // as.deleteCustomer(3);
       // cs.addCoupon(coupon);
       // as.deleteCompany(1);

       // cs.getCompanyDetails();
       // cs.addCoupon(coupon);
       // as.getSingleCompany(2);
        //as.deleteCompany(1);


    }
}
