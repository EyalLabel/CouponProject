package com.couponProject.couponProject.Controllers;

import com.couponProject.couponProject.Exceptions.SystemException;
import com.couponProject.couponProject.beans.Coupon;
import com.couponProject.couponProject.services.CompanyService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("company")
@RequiredArgsConstructor
public class CompanyController {
    private final CompanyService company;
    @GetMapping("all")  //http://localhost:8080/school/all
    public ResponseEntity<?> getCompanyCoupons(){
        return new ResponseEntity<>(company.getCompanyCoupons(), HttpStatus.OK);
    }
    @PostMapping("add") //http://localhost:8080/school/add
    public ResponseEntity<?> addCoupon(@RequestBody Coupon coupon) throws SystemException {
        company.addCoupon(coupon);
        return new ResponseEntity<>( HttpStatus.CREATED);
    }
}
