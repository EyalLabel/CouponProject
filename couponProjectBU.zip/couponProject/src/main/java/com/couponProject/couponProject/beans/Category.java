package com.couponProject.couponProject.beans;


public enum Category {
    FOOD,ELECTRICITY,RESTAURANT,VACATION,FASHION
}
