package com.couponProject.couponProject.LoginManager;

public enum ClientType {
    ADMINISTRATOR,COMPANY,CUSTOMER
}
